
setProductsDOM();